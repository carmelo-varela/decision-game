package com.example.alphaprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {

    // Initialises index and scene to then be set by the next node

    int index = 0;
    int scene = 0;

    // Method to return JSON arrays

    public JSONArray returnJSON() throws JSONException {
        JSONArray arr = new JSONArray(loadJSONFromAsset(getApplicationContext()));
        return arr;
    }

    // Method to get and return id that points to the next node

    public JSONObject getPointer() throws JSONException {
        JSONObject pointers = returnJSON().getJSONObject(index).getJSONObject("content");
        return pointers;
    }

    public void setScene(View view) throws JSONException {
        JSONObject JSONObj = returnJSON().getJSONObject(index);

        RelativeLayout relativeLayout = findViewById(R.id.relativeLayout);

        TextView messageTextView = findViewById(R.id.message);
        TextView questionTextView = findViewById(R.id.question);
        Button opt1button = findViewById(R.id.option1);
        Button opt2button = findViewById(R.id.option2);
        Button opt3button = findViewById(R.id.option3);

        String messageText = JSONObj.getString("message");
        String questionText = JSONObj.getString("question");
        String opt1Text = JSONObj.getJSONObject("content").getJSONArray("opt1").getString(0);
        String opt2Text = JSONObj.getJSONObject("content").getJSONArray("opt2").getString(0);
        String opt3Text = JSONObj.getJSONObject("content").getJSONArray("opt3").getString(0);

        // Conditions that allow switching of background drawable in relation to scene of current index

        if (scene == 0) {
            relativeLayout.setBackgroundResource(R.drawable.three_option);

            messageTextView.setVisibility(View.VISIBLE);
            questionTextView.setVisibility(View.VISIBLE);
            opt1button.setVisibility(View.VISIBLE);
            opt2button.setVisibility(View.VISIBLE);
            opt3button.setVisibility(View.VISIBLE);

            messageTextView.setText(messageText);
            questionTextView.setText(questionText);
            opt1button.setText(opt1Text);
            opt2button.setText(opt2Text);
            opt3button.setText(opt3Text);

            messageTextView.setTextColor(getResources().getColor(R.color.orange));
            questionTextView.setTextColor(getResources().getColor(R.color.orange));
            opt1button.setTextColor(getResources().getColor(R.color.orange));
            opt2button.setTextColor(getResources().getColor(R.color.orange));
            opt3button.setTextColor(getResources().getColor(R.color.orange));
        } else if (scene == 1) {
            relativeLayout.setBackgroundResource(R.drawable.two_option);

            messageTextView.setVisibility(View.VISIBLE);
            questionTextView.setVisibility(View.VISIBLE);
            opt1button.setVisibility(View.VISIBLE);
            opt2button.setVisibility(View.VISIBLE);
            opt3button.setVisibility(View.GONE);

            messageTextView.setText(messageText);
            questionTextView.setText(questionText);
            opt1button.setText(opt1Text);
            opt2button.setText(opt2Text);

            messageTextView.setTextColor(getResources().getColor(R.color.orange));
            questionTextView.setTextColor(getResources().getColor(R.color.orange));
            opt1button.setTextColor(getResources().getColor(R.color.orange));
            opt2button.setTextColor(getResources().getColor(R.color.orange));
        } else if (scene == 2) {
            relativeLayout.setBackgroundResource(R.drawable.one_option);

            messageTextView.setVisibility(View.VISIBLE);
            questionTextView.setVisibility(View.VISIBLE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            messageTextView.setText(messageText);
            questionTextView.setText(questionText);
            opt3button.setText(opt3Text);

            messageTextView.setTextColor(getResources().getColor(R.color.orange));
            questionTextView.setTextColor(getResources().getColor(R.color.orange));
            opt3button.setTextColor(getResources().getColor(R.color.orange));
        } else if (scene == 3) {
            relativeLayout.setBackgroundResource(R.drawable.invalid);

            messageTextView.setVisibility(View.VISIBLE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            messageTextView.setText(messageText);
            opt3button.setText(opt3Text);

            messageTextView.setTextColor(getResources().getColor(R.color.red));
            opt3button.setTextColor(getResources().getColor(R.color.red));
        } else if (scene == 4) {
            relativeLayout.setBackgroundResource(R.drawable.valid);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            messageTextView.setText(messageText);
            opt3button.setText(opt3Text);

            messageTextView.setTextColor(getResources().getColor(R.color.green));
            opt3button.setTextColor(getResources().getColor(R.color.green));
        } else if (scene == 5) {
            relativeLayout.setBackgroundResource(R.drawable.base_exterior_one);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            opt3button.setText(opt3Text);

            opt3button.setTextColor(getResources().getColor(R.color.white));
        } else if (scene == 6) {
            relativeLayout.setBackgroundResource(R.drawable.base_exterior_two);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            opt3button.setText(opt3Text);

            opt3button.setTextColor(getResources().getColor(R.color.white));
        } else if (scene == 7) {
            relativeLayout.setBackgroundResource(R.drawable.escape_pod_window);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            opt3button.setText(opt3Text);

            opt3button.setTextColor(getResources().getColor(R.color.white));
        } else if (scene == 8) {
            relativeLayout.setBackgroundResource(R.drawable.moon_sat_view);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            opt3button.setText(opt3Text);

            opt3button.setTextColor(getResources().getColor(R.color.orange));
        } else if (scene == 9) {
            relativeLayout.setBackgroundResource(R.drawable.earth_pod_view);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.VISIBLE);

            opt3button.setText(opt3Text);

            opt3button.setTextColor(getResources().getColor(R.color.white));
        } else if (scene == 10) {
            relativeLayout.setBackgroundResource(R.drawable.circuit);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.VISIBLE);
            opt2button.setVisibility(View.VISIBLE);
            opt3button.setVisibility(View.GONE);

            opt1button.setText(opt1Text);
            opt2button.setText(opt2Text);
        } else {
            relativeLayout.setBackgroundResource(R.drawable.end);

            messageTextView.setVisibility(View.GONE);
            questionTextView.setVisibility(View.GONE);
            opt1button.setVisibility(View.GONE);
            opt2button.setVisibility(View.GONE);
            opt3button.setVisibility(View.GONE);
        }
    }

    // Initialises application

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Hide status bar

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

    // Ensure status bar remains hidden when resuming the app

    @Override
    protected void onResume() {
        super.onResume();
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

    // Method to load JSON file

    public String loadJSONFromAsset(Context context) {
        String json;
        try {
            InputStream is = context.getAssets().open("script.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return json;
    }

    // Functions that allow button to map between different nodes of the decision map
    
    public  void OnClickHandler1(View view) throws JSONException {
        String id = getPointer().getJSONArray("opt1").getString(1);
        index = Integer.valueOf(id);
        String sceneid = getPointer().getJSONArray("sceneType").getString(0);
        scene = Integer.valueOf(sceneid);
        setScene(view);
    }

    public  void OnClickHandler2(View view) throws JSONException {
        String id = getPointer().getJSONArray("opt2").getString(1);
        index = Integer.valueOf(id);
        String sceneid = getPointer().getJSONArray("sceneType").getString(0);
        scene = Integer.valueOf(sceneid);
        setScene(view);
    }

    public  void OnClickHandler3(View view) throws JSONException {
        String id = getPointer().getJSONArray("opt3").getString(1);
        index = Integer.valueOf(id);
        String sceneid = getPointer().getJSONArray("sceneType").getString(0);
        scene = Integer.valueOf(sceneid);
        setScene(view);
    }
}